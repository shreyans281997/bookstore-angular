﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { CustomerRegisterationComponent} from './app.registerCustomer';
import { FormsModule, FormBuilder, FormGroup } from '@angular/forms';
import { Routes,RouterModule  } from '@angular/router';
import { showCustomersComponent } from './app.showAllCustomerComponent';
const router:Routes=[
    {path:'add',component:CustomerRegisterationComponent},
    {path:'showAll',component:showCustomersComponent}
]


@NgModule({
    imports: [
        BrowserModule, FormsModule, HttpClientModule, RouterModule.forRoot(router)
        
    ],
    declarations: [
        AppComponent, CustomerRegisterationComponent, showCustomersComponent
		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }