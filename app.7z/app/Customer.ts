import { Address } from "./Address";

export class Customer{
    fullName:Text
    emailId:Text
    password:Text
    phoneNumber:Number
    street:Text
    city:Text
    country:Text
    zipCode:Number;

}