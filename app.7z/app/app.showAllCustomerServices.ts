import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";

@Injectable({
    providedIn:'root'
})
export class showAllCustomerServices{
constructor(private httpdata:HttpClient){}
//customerAll:any=[{}]
    showAllCustomers():any{
        return this.httpdata.get("http://localhost:7859/customer/showAll");

    }
    deleteCustomers():any{
        

    }
}