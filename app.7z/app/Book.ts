export class Book{
	title:Text
    author:Text
    description:Text
    ISDNnumber:Number
	thumbnailImage:Text
    price:Number
    publishDate:Text
    quantity :Number
    categoryId:Number;
}