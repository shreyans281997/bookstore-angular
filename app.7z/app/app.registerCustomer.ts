import { Component } from "@angular/core";
import { CustomerServices } from "./app.registercomponentservice";
import {Customer} from './Customer';



@Component({
    selector:'register-customer',
    templateUrl:'app.registerCustomer.html'
})
export class CustomerRegisterationComponent{
constructor(private customServices:CustomerServices){}
customer:any={}

registerCustomer():any{
    this.customServices.registerCustomer(this.customer).subscribe();

}

}