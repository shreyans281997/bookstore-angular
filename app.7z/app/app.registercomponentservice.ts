import { Component, Injectable } from "@angular/core";
import {HttpClient} from '@angular/common/http';
import {Customer} from './Customer';
//import {Address} from './Address';

@Injectable({
    providedIn:'root'
})

export class CustomerServices{
  constructor(private httpdata:HttpClient){}
  registerCustomer(data:any){
    console.log(data);
    let input=new FormData();
    input.append("fullName",data.fullName);
    input.append("emailId",data.emailId);
    input.append("password",data.password);
    input.append("phoneNumber",data.phoneNumber);
    input.append("address.country",data.country);
    input.append("address.city",data.city);
    input.append("address.street",data.street);
    input.append("address.zipCode",data.zipCode);
     return this.httpdata.post("http://localhost:7859/customer/acceptDetails",input);
}
}