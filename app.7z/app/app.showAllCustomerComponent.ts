import { Component, OnInit } from "@angular/core";
import { showAllCustomerServices } from "./app.showAllCustomerServices";


@Component({
    selector:"show-all",
    templateUrl:"app.showAllCustomers.html"
})
export class showCustomersComponent implements OnInit{
constructor(private customerServices:showAllCustomerServices){}
customAll:any[];
ngOnInit(){
    this.customerServices.showAllCustomers().subscribe((data:any)=>this.customAll=data)
}

    deleteCustomer(){
        
    }

}